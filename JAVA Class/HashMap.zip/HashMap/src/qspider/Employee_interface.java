package qspider;

public interface Employee_interface {
	void netpay();

}
